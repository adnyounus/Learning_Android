package com.example.learningandroid;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Calculator extends AppCompatActivity {
    private Button btn0, btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9;
    private Button btnMinus,btnPlus,btnEqual,btnMultiply,btnDivide,btnClear,btnMod;
    private TextView txtResult;

    Integer firstInput=0, secondInput=0;
    Boolean isAdd,isMultiply,isDivision,isSub,isMod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);
        btn0= findViewById(R.id.num_0);
        btn1= findViewById(R.id.num_1);
        btn2=findViewById(R.id.num_2);
        btn3=findViewById(R.id.num_3);
        btn4= findViewById(R.id.num_4);
        btn5= findViewById(R.id.num_5);
        btn6=findViewById(R.id.num_6);
        btn7=findViewById(R.id.num_7);
        btn8= findViewById(R.id.num_8);
        btn9= findViewById(R.id.num_9);

        btnMinus=findViewById(R.id.btn_minus);
        btnPlus=findViewById(R.id.btn_plus);
        btnEqual=findViewById(R.id.btn_equal);
        btnClear=findViewById(R.id.btn_clr);
        btnDivide=findViewById(R.id.btn_divide);
        btnMultiply=findViewById(R.id.btn_multiple);
        btnMod=findViewById(R.id.btn_mod);

        txtResult=findViewById(R.id.txt_result);

        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txtResult.getText().toString().length()!=0){
                    firstInput= Integer.valueOf(txtResult.getText().toString());
                    isAdd=true;
                    txtResult.setText(null);
                }
            }
        });
        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txtResult.getText().toString().length()!=0){
                    firstInput= Integer.valueOf(txtResult.getText().toString());
                    isSub=true;
                    txtResult.setText(null);
                }
            }
        });
        btnDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txtResult.getText().toString().length()!=0){
                    firstInput= Integer.valueOf(txtResult.getText().toString());
                    isDivision=true;
                    txtResult.setText(null);
                }
            }
        });
        btnMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txtResult.getText().toString().length()!=0){
                    firstInput= Integer.valueOf(txtResult.getText().toString());
                    isMultiply=true;
                    txtResult.setText(null);
                }
            }
        });
        btnMod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(txtResult.getText().toString().length()!=0){
                    firstInput= Integer.valueOf(txtResult.getText().toString());
                    isMod=true;
                    txtResult.setText(null);
                }
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    firstInput= 0;
                    secondInput=0;
                    txtResult.setText("");

            }
        });
        btnEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isAdd || isSub || isMultiply || isDivision || isMod){
                    secondInput= Integer.valueOf(txtResult.getText().toString());
                }
                if(isAdd){
                    txtResult.setText(firstInput+secondInput+"");
                    isAdd=false;
                }
                if(isSub){
                    txtResult.setText(firstInput-secondInput+"");
                    isSub=false;
                }
                if(isMultiply){
                    txtResult.setText(firstInput*secondInput+"");
                    isMultiply=false;
                }
                if(isDivision){
                    Double resultValue= Double.valueOf(firstInput/secondInput);
                    txtResult.setText(String.format("%.2f",resultValue));
                    isDivision=false;
                }
                if(isMod){
                    txtResult.setText(firstInput%secondInput+"");
                    isMod=false;
                }
            }
        });

    }
    public void numberOperation(View v){
        Button button= (Button) v;
        txtResult.setText(txtResult.getText().toString()+button.getText().toString());
    }
}